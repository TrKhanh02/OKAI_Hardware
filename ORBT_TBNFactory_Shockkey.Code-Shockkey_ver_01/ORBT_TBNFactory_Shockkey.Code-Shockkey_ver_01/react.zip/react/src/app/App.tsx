import { useState } from 'react';
import { SensorPanel } from '@/app/components/SensorPanel';
import { UserForm } from '@/app/components/UserForm';
import { UserList, User } from '@/app/components/UserList';
import { Lock } from 'lucide-react';
import { Toaster } from '@/app/components/ui/sonner';
import { toast } from 'sonner';

const MAX_USERS = 100;

export default function App() {
  const [users, setUsers] = useState<User[]>([]);
  const [rfidValue, setRfidValue] = useState('');
  const [fingerprintValue, setFingerprintValue] = useState('');
  const [selectedUserForView, setSelectedUserForView] = useState<User | null>(null);

  const handleAddUser = (name: string, rfid: string, fingerprint: string) => {
    if (users.length >= MAX_USERS) {
      toast.error(`Maximum capacity reached! Cannot add more than ${MAX_USERS} users.`);
      return;
    }

    // Find the next available slot ID (1-100)
    const usedIds = new Set(users.map(u => parseInt(u.id)));
    let nextId = 1;
    while (usedIds.has(nextId) && nextId <= MAX_USERS) {
      nextId++;
    }

    if (nextId > MAX_USERS) {
      toast.error(`No available slots!`);
      return;
    }

    const newUser: User = {
      id: nextId.toString(),
      name,
      rfid: rfid || undefined,
      fingerprint: fingerprint || undefined,
      addedAt: new Date()
    };

    setUsers(prev => [...prev, newUser]);
    toast.success(`User "${name}" added to slot #${nextId}!`);
  };

  const handleEditUser = (id: string, name: string, rfid: string, fingerprint: string) => {
    setUsers(prev => prev.map(u => 
      u.id === id 
        ? { ...u, name, rfid: rfid || undefined, fingerprint: fingerprint || undefined }
        : u
    ));
    toast.success(`User information updated for slot #${id}!`);
  };

  const handleDeleteUser = (id: string) => {
    const user = users.find(u => u.id === id);
    setUsers(prev => prev.filter(u => u.id !== id));
    toast.success(`User "${user?.name}" removed from slot #${id}!`);
  };

  const handleSelectRFID = (code: string) => {
    setRfidValue(code);
    toast.info('RFID code selected from sensor');
  };

  const handleSelectFingerprint = (code: string) => {
    setFingerprintValue(code);
    toast.info('Fingerprint code selected from sensor');
  };

  const handleUserSelect = (user: User) => {
    setSelectedUserForView(user);
    toast.success(`Found user: ${user.name} in slot #${user.id}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-50 dark:from-slate-950 dark:via-blue-950 dark:to-slate-950">
      <Toaster richColors position="top-right" />
      
      {/* Header */}
      <div className="border-b bg-card/80 backdrop-blur-sm shadow-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 sm:py-6">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="p-2 sm:p-2.5 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl shadow-lg">
              <Lock className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
            </div>
            <div>
              <h1 className="text-lg sm:text-2xl font-bold bg-gradient-to-r from-blue-600 to-blue-800 dark:from-blue-400 dark:to-blue-600 bg-clip-text text-transparent">
                Lock Key Management
              </h1>
              <p className="text-xs sm:text-sm text-muted-foreground hidden sm:block">
                Secure access control with RFID cards and fingerprint authentication
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-4 sm:py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
          {/* Left Column - Form and User List */}
          <div className="lg:col-span-2 space-y-4 sm:space-y-6">
            <UserForm
              rfidValue={rfidValue}
              fingerprintValue={fingerprintValue}
              onRfidChange={setRfidValue}
              onFingerprintChange={setFingerprintValue}
              onAddUser={handleAddUser}
            />
            
            <UserList 
              users={users} 
              onDeleteUser={handleDeleteUser} 
              onEditUser={handleEditUser}
              onUserSelect={handleUserSelect}
              latestRfid={rfidValue}
              latestFingerprint={fingerprintValue}
            />
          </div>

          {/* Right Column - Sensor Panel */}
          <div className="lg:col-span-1 order-first lg:order-last">
            <SensorPanel
              onSelectRFID={handleSelectRFID}
              onSelectFingerprint={handleSelectFingerprint}
            />
          </div>
        </div>
      </div>
    </div>
  );
}