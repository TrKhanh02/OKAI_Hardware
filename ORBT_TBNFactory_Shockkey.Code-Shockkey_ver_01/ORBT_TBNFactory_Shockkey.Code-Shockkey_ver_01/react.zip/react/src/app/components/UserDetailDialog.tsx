import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/app/components/ui/dialog';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Badge } from '@/app/components/ui/badge';
import { CreditCard, Fingerprint, Trash2, Save, X, Radio } from 'lucide-react';
import { User } from './UserList';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/app/components/ui/alert-dialog';

interface UserDetailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  user: User | null;
  onEdit: (id: string, name: string, rfid: string, fingerprint: string) => void;
  onDelete: (id: string) => void;
  latestRfid?: string;
  latestFingerprint?: string;
}

export function UserDetailDialog({ open, onOpenChange, user, onEdit, onDelete, latestRfid, latestFingerprint }: UserDetailDialogProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState('');
  const [editRfid, setEditRfid] = useState('');
  const [editFingerprint, setEditFingerprint] = useState('');
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  const handleEdit = () => {
    if (user) {
      setEditName(user.name);
      setEditRfid(user.rfid || '');
      setEditFingerprint(user.fingerprint || '');
      setIsEditing(true);
    }
  };

  const handleGetLatestRfid = () => {
    if (latestRfid) {
      setEditRfid(latestRfid);
    }
  };

  const handleGetLatestFingerprint = () => {
    if (latestFingerprint) {
      setEditFingerprint(latestFingerprint);
    }
  };

  const handleSave = () => {
    if (user && editName.trim() && (editRfid || editFingerprint)) {
      onEdit(user.id, editName, editRfid, editFingerprint);
      setIsEditing(false);
      onOpenChange(false);
    }
  };

  const handleCancel = () => {
    setIsEditing(false);
    setEditName('');
    setEditRfid('');
    setEditFingerprint('');
  };

  const handleDelete = () => {
    if (user) {
      onDelete(user.id);
      setShowDeleteDialog(false);
      onOpenChange(false);
    }
  };

  if (!user) return null;

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Slot #{user.id} - User Details</DialogTitle>
            <DialogDescription>
              {isEditing ? 'Edit user information' : 'View or modify user details'}
            </DialogDescription>
          </DialogHeader>

          {isEditing ? (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">User Name</Label>
                <Input
                  id="edit-name"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  placeholder="Enter user name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-rfid">RFID Code</Label>
                <div className="flex gap-2">
                  <Input
                    id="edit-rfid"
                    value={editRfid}
                    onChange={(e) => setEditRfid(e.target.value)}
                    placeholder="RFID code"
                    readOnly
                    className="flex-1"
                  />
                  <Button 
                    onClick={handleGetLatestRfid} 
                    variant="outline" 
                    size="sm"
                    disabled={!latestRfid}
                    title={latestRfid ? `Get latest: ${latestRfid}` : 'No RFID data available'}
                  >
                    <Radio className="h-4 w-4" />
                  </Button>
                </div>
                {latestRfid && (
                  <p className="text-xs text-muted-foreground">
                    Latest: {latestRfid}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-fingerprint">Fingerprint Code</Label>
                <div className="flex gap-2">
                  <Input
                    id="edit-fingerprint"
                    value={editFingerprint}
                    onChange={(e) => setEditFingerprint(e.target.value)}
                    placeholder="Fingerprint code"
                    readOnly
                    className="flex-1"
                  />
                  <Button 
                    onClick={handleGetLatestFingerprint} 
                    variant="outline" 
                    size="sm"
                    disabled={!latestFingerprint}
                    title={latestFingerprint ? `Get latest: ${latestFingerprint}` : 'No fingerprint data available'}
                  >
                    <Radio className="h-4 w-4" />
                  </Button>
                </div>
                {latestFingerprint && (
                  <p className="text-xs text-muted-foreground">
                    Latest: {latestFingerprint}
                  </p>
                )}
              </div>

              <div className="flex gap-2 pt-2">
                <Button onClick={handleSave} className="flex-1" disabled={!editName.trim() || (!editRfid && !editFingerprint)}>
                  <Save className="h-4 w-4 mr-2" />
                  Save Changes
                </Button>
                <Button onClick={handleCancel} variant="outline" className="flex-1">
                  <X className="h-4 w-4 mr-2" />
                  Cancel
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>User Name</Label>
                <p className="text-sm font-medium">{user.name}</p>
              </div>

              <div className="space-y-2">
                <Label>Authentication Methods</Label>
                <div className="flex flex-wrap gap-2">
                  {user.rfid && (
                    <Badge variant="outline" className="text-xs">
                      <CreditCard className="h-3 w-3 mr-1" />
                      {user.rfid}
                    </Badge>
                  )}
                  {user.fingerprint && (
                    <Badge variant="outline" className="text-xs">
                      <Fingerprint className="h-3 w-3 mr-1" />
                      {user.fingerprint}
                    </Badge>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Registration Date</Label>
                <p className="text-sm text-muted-foreground">
                  {user.addedAt.toLocaleString()}
                </p>
              </div>

              <div className="flex gap-2 pt-2">
                <Button onClick={handleEdit} variant="outline" className="flex-1">
                  Edit
                </Button>
                <Button onClick={() => setShowDeleteDialog(true)} variant="destructive" className="flex-1">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete User</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete <strong>{user.name}</strong> from slot #{user.id}? 
              This action cannot be undone and will remove all their access credentials.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}