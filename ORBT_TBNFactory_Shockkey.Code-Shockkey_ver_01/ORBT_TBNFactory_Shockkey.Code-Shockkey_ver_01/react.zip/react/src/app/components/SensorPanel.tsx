import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Fingerprint, CreditCard, RefreshCw } from 'lucide-react';
import { ScrollArea } from '@/app/components/ui/scroll-area';
import { Badge } from '@/app/components/ui/badge';

interface SensorData {
  id: string;
  type: 'rfid' | 'fingerprint';
  code: string;
  timestamp: Date;
}

interface SensorPanelProps {
  onSelectRFID: (code: string) => void;
  onSelectFingerprint: (code: string) => void;
}

export function SensorPanel({ onSelectRFID, onSelectFingerprint }: SensorPanelProps) {
  const [sensorData, setSensorData] = useState<SensorData[]>([]);

  // Simulate sensor readings
  const generateSensorData = () => {
    const type = Math.random() > 0.5 ? 'rfid' : 'fingerprint';
    const code = type === 'rfid' 
      ? `RFID-${Math.random().toString(36).substring(2, 10).toUpperCase()}`
      : `FP-${Math.random().toString(36).substring(2, 14).toUpperCase()}`;

    const newData: SensorData = {
      id: Date.now().toString(),
      type,
      code,
      timestamp: new Date()
    };

    setSensorData(prev => [newData, ...prev].slice(0, 10));
  };

  useEffect(() => {
    // Simulate periodic sensor readings
    const interval = setInterval(() => {
      if (Math.random() > 0.7) {
        generateSensorData();
      }
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const handleSelect = (data: SensorData) => {
    if (data.type === 'rfid') {
      onSelectRFID(data.code);
    } else {
      onSelectFingerprint(data.code);
    }
  };

  return (
    <Card className="h-full shadow-lg border-0 bg-gradient-to-br from-card to-card/50">
      <CardHeader className="pb-3">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
          <CardTitle className="text-base sm:text-lg flex items-center gap-2">
            <div className="p-1.5 sm:p-2 bg-blue-500/10 rounded-lg">
              <RefreshCw className="h-3 w-3 sm:h-4 sm:w-4 text-blue-500" />
            </div>
            Sensor Readings
          </CardTitle>
          <Button
            variant="outline"
            size="sm"
            onClick={generateSensorData}
            className="w-full sm:w-auto h-8"
          >
            <RefreshCw className="h-3 w-3 sm:h-4 sm:w-4 mr-1.5" />
            <span className="text-xs sm:text-sm">Scan</span>
          </Button>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-1.5 sm:space-y-2">
          {sensorData.length === 0 ? (
            <div className="text-center py-6 sm:py-8 text-muted-foreground">
              <div className="p-3 bg-muted/50 rounded-full w-fit mx-auto mb-2">
                <RefreshCw className="h-6 w-6 sm:h-8 sm:w-8 opacity-20" />
              </div>
              <p className="text-xs sm:text-sm">No sensor data yet</p>
              <p className="text-xs text-muted-foreground/60 mt-1 hidden sm:block">
                Click "Scan" or wait for readings
              </p>
            </div>
          ) : (
            <ScrollArea className="h-[200px] sm:h-auto sm:max-h-[400px]">
              <div className="space-y-1.5 sm:space-y-2 pr-2">
                {sensorData.map((data) => (
                  <div
                    key={data.id}
                    className="flex items-center justify-between p-2 sm:p-3 border rounded-lg hover:bg-accent/50 active:bg-accent cursor-pointer transition-all hover:shadow-md group"
                    onClick={() => handleSelect(data)}
                  >
                    <div className="flex items-center gap-2 sm:gap-3 flex-1 min-w-0">
                      <div className={`p-1.5 rounded-lg ${data.type === 'rfid' ? 'bg-blue-500/10' : 'bg-purple-500/10'}`}>
                        {data.type === 'rfid' ? (
                          <CreditCard className="h-3 w-3 sm:h-4 sm:w-4 text-blue-500 flex-shrink-0" />
                        ) : (
                          <Fingerprint className="h-3 w-3 sm:h-4 sm:w-4 text-purple-500 flex-shrink-0" />
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-xs sm:text-sm font-medium truncate">{data.code}</p>
                        <p className="text-xs text-muted-foreground">
                          {data.timestamp.toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity hidden sm:block">
                      <Badge variant="secondary" className="text-xs">Use</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          )}
        </div>
      </CardContent>
    </Card>
  );
}