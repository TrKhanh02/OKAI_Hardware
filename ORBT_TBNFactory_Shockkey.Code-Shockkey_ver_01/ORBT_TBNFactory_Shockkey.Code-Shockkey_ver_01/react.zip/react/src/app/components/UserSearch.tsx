import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/app/components/ui/dialog';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Badge } from '@/app/components/ui/badge';
import { ScrollArea } from '@/app/components/ui/scroll-area';
import { Search, UserCheck, CreditCard, Fingerprint } from 'lucide-react';
import { User } from './UserList';

interface UserSearchProps {
  users: User[];
  onUserSelect: (user: User) => void;
}

export function UserSearch({ users, onUserSelect }: UserSearchProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [open, setOpen] = useState(false);

  const filteredUsers = users.filter(user =>
    user.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleUserClick = (user: User) => {
    onUserSelect(user);
    setOpen(false);
    setSearchQuery('');
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <Search className="h-4 w-4" />
          <span className="hidden sm:inline">Search User</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Search Users</DialogTitle>
          <DialogDescription>
            Search for a registered user by name to view their slot ID
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Type user name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
              autoFocus
            />
          </div>

          {searchQuery && (
            <ScrollArea className="h-[300px]">
              <div className="space-y-2">
                {filteredUsers.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <UserCheck className="h-12 w-12 mx-auto mb-3 opacity-20" />
                    <p className="text-sm">No users found matching "{searchQuery}"</p>
                  </div>
                ) : (
                  filteredUsers.map((user) => (
                    <div
                      key={user.id}
                      onClick={() => handleUserClick(user)}
                      className="flex items-center justify-between p-3 border rounded-lg hover:bg-accent cursor-pointer transition-colors group"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="font-medium text-sm">{user.name}</p>
                          <Badge variant="default" className="text-xs">
                            Slot #{user.id}
                          </Badge>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {user.rfid && (
                            <Badge variant="outline" className="text-xs">
                              <CreditCard className="h-3 w-3 mr-1" />
                              RFID
                            </Badge>
                          )}
                          {user.fingerprint && (
                            <Badge variant="outline" className="text-xs">
                              <Fingerprint className="h-3 w-3 mr-1" />
                              Fingerprint
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div className="ml-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button variant="ghost" size="sm">View</Button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>
          )}

          {!searchQuery && users.length > 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <Search className="h-12 w-12 mx-auto mb-3 opacity-20" />
              <p className="text-sm">Start typing to search for users</p>
              <p className="text-xs mt-1">{users.length} users registered</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
