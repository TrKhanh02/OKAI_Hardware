import { Card, CardContent, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { ScrollArea } from '@/app/components/ui/scroll-area';
import { Trash2, CreditCard, Fingerprint, Users } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/app/components/ui/alert-dialog';
import { SlotView } from './SlotView';
import { UserSearch } from './UserSearch';

export interface User {
  id: string;
  name: string;
  rfid?: string;
  fingerprint?: string;
  addedAt: Date;
}

interface UserListProps {
  users: User[];
  onDeleteUser: (id: string) => void;
  onEditUser: (id: string, name: string, rfid: string, fingerprint: string) => void;
  onUserSelect: (user: User) => void;
  latestRfid?: string;
  latestFingerprint?: string;
  maxSlots?: number;
}

export function UserList({ users, onDeleteUser, onEditUser, onUserSelect, latestRfid, latestFingerprint, maxSlots = 100 }: UserListProps) {
  return (
    <Card className="shadow-lg border-0 bg-gradient-to-br from-card to-card/50">
      <CardHeader>
        <div className="flex items-center justify-between flex-wrap gap-2">
          <CardTitle className="flex items-center gap-2">
            <div className="p-2 bg-primary/10 rounded-lg">
              <Users className="h-4 w-4 text-primary" />
            </div>
            Registered Users
          </CardTitle>
          <div className="flex items-center gap-2">
            <UserSearch users={users} onUserSelect={onUserSelect} />
            <SlotView 
              users={users} 
              maxSlots={maxSlots} 
              onEditUser={onEditUser} 
              onDeleteUser={onDeleteUser}
              latestRfid={latestRfid}
              latestFingerprint={latestFingerprint}
            />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {users.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <Users className="h-12 w-12 mx-auto mb-3 opacity-20" />
            <p>No users registered yet</p>
            <p className="text-sm">Add a user to get started</p>
          </div>
        ) : (
          <ScrollArea className="h-[300px] sm:h-[400px] pr-2 sm:pr-4">
            <div className="space-y-2 sm:space-y-3">
              {users.map((user) => (
                <div
                  key={user.id}
                  className="flex items-center justify-between p-3 sm:p-4 border rounded-lg hover:bg-accent transition-colors"
                >
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium mb-1 sm:mb-2 text-sm sm:text-base">{user.name}</h3>
                    <div className="flex flex-wrap gap-1 sm:gap-2">
                      {user.rfid && (
                        <Badge variant="outline" className="text-xs">
                          <CreditCard className="h-3 w-3 mr-1" />
                          <span className="truncate max-w-[120px]">{user.rfid}</span>
                        </Badge>
                      )}
                      {user.fingerprint && (
                        <Badge variant="outline" className="text-xs">
                          <Fingerprint className="h-3 w-3 mr-1" />
                          <span className="truncate max-w-[120px]">{user.fingerprint}</span>
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1 sm:mt-2 hidden sm:block">
                      Added: {user.addedAt.toLocaleString()}
                    </p>
                  </div>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="ghost" size="sm" className="ml-2">
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete User</AlertDialogTitle>
                        <AlertDialogDescription>
                          Are you sure you want to delete <strong>{user.name}</strong>? 
                          This action cannot be undone and will remove all their access credentials.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => onDeleteUser(user.id)}
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        >
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
}