import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { UserPlus } from 'lucide-react';

interface UserFormProps {
  rfidValue: string;
  fingerprintValue: string;
  onRfidChange: (value: string) => void;
  onFingerprintChange: (value: string) => void;
  onAddUser: (name: string, rfid: string, fingerprint: string) => void;
}

export function UserForm({ 
  rfidValue, 
  fingerprintValue, 
  onRfidChange, 
  onFingerprintChange, 
  onAddUser 
}: UserFormProps) {
  const [userName, setUserName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (userName.trim() && (rfidValue || fingerprintValue)) {
      onAddUser(userName, rfidValue, fingerprintValue);
      setUserName('');
      onRfidChange('');
      onFingerprintChange('');
    }
  };

  return (
    <Card className="shadow-lg border-0 bg-gradient-to-br from-card to-card/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <div className="p-2 bg-green-500/10 rounded-lg">
            <UserPlus className="h-4 w-4 text-green-600" />
          </div>
          Add New User
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="userName">User Name</Label>
            <Input
              id="userName"
              placeholder="Enter user name"
              value={userName}
              onChange={(e) => setUserName(e.target.value)}
              required
              className="transition-all focus:ring-2 focus:ring-primary/20"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="rfid">RFID Code</Label>
            <Input
              id="rfid"
              placeholder="Scan RFID card or select from sensor"
              value={rfidValue}
              onChange={(e) => onRfidChange(e.target.value)}
              className="transition-all focus:ring-2 focus:ring-blue-500/20"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="fingerprint">Fingerprint Code</Label>
            <Input
              id="fingerprint"
              placeholder="Scan fingerprint or select from sensor"
              value={fingerprintValue}
              onChange={(e) => onFingerprintChange(e.target.value)}
              className="transition-all focus:ring-2 focus:ring-purple-500/20"
            />
          </div>

          <Button 
            type="submit" 
            className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 shadow-md hover:shadow-lg transition-all" 
            disabled={!userName.trim() || (!rfidValue && !fingerprintValue)}
          >
            <UserPlus className="h-4 w-4 mr-2" />
            Add User
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}