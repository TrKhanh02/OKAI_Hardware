import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/app/components/ui/dialog';
import { Badge } from '@/app/components/ui/badge';
import { ScrollArea } from '@/app/components/ui/scroll-area';
import { User } from './UserList';
import { UserDetailDialog } from './UserDetailDialog';
import { Users, Lock, LockOpen } from 'lucide-react';

interface SlotViewProps {
  users: User[];
  maxSlots: number;
  onEditUser: (id: string, name: string, rfid: string, fingerprint: string) => void;
  onDeleteUser: (id: string) => void;
  latestRfid?: string;
  latestFingerprint?: string;
}

export function SlotView({ users, maxSlots, onEditUser, onDeleteUser, latestRfid, latestFingerprint }: SlotViewProps) {
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  // Create an array of all slots (1-100)
  const slots = Array.from({ length: maxSlots }, (_, index) => {
    const slotNumber = index + 1;
    const user = users.find(u => parseInt(u.id) === slotNumber);
    return {
      slotNumber,
      isOccupied: !!user,
      user,
    };
  });

  const handleSlotClick = (slot: { slotNumber: number; isOccupied: boolean; user?: User }) => {
    if (slot.user) {
      setSelectedUser(slot.user);
      setDetailDialogOpen(true);
    }
  };

  return (
    <>
      <Dialog>
      <DialogTrigger asChild>
        <Badge variant="secondary" className="cursor-pointer hover:bg-secondary/80 transition-colors">
          <Users className="h-3 w-3 mr-1" />
          {users.length}
        </Badge>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle>ID Slot Overview</DialogTitle>
          <DialogDescription>
            Viewing all {maxSlots} available slots. Red indicates occupied slots, green indicates available slots.
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex gap-4 mb-4">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-red-500 rounded"></div>
            <span className="text-sm">Occupied ({users.length})</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-green-500 rounded"></div>
            <span className="text-sm">Available ({maxSlots - users.length})</span>
          </div>
        </div>

        <ScrollArea className="h-[400px] sm:h-[500px] pr-4">
          <div className="grid grid-cols-5 sm:grid-cols-8 md:grid-cols-10 gap-2">
            {slots.map((slot) => (
              <div
                key={slot.slotNumber}
                onClick={() => handleSlotClick(slot)}
                className={`
                  relative aspect-square rounded-lg border-2 flex flex-col items-center justify-center
                  transition-all cursor-pointer hover:scale-105 active:scale-95
                  ${slot.isOccupied 
                    ? 'bg-red-500 border-red-600 text-white hover:bg-red-600' 
                    : 'bg-green-500 border-green-600 text-white hover:bg-green-600'
                  }
                `}
                title={slot.user ? `ID ${slot.slotNumber}: ${slot.user.name}` : `ID ${slot.slotNumber}: Available`}
              >
                {slot.isOccupied ? (
                  <Lock className="h-3 w-3 sm:h-4 sm:w-4 mb-1" />
                ) : (
                  <LockOpen className="h-3 w-3 sm:h-4 sm:w-4 mb-1" />
                )}
                <span className="text-xs font-semibold">{slot.slotNumber}</span>
              </div>
            ))}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>

    <UserDetailDialog
      open={detailDialogOpen}
      onOpenChange={setDetailDialogOpen}
      user={selectedUser}
      onEdit={onEditUser}
      onDelete={onDeleteUser}
      latestRfid={latestRfid}
      latestFingerprint={latestFingerprint}
    />
    </>
  );
}